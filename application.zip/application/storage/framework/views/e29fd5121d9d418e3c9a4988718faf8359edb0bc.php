<?php $__env->startSection('custom-css'); ?>
    <style>
        a {
            font-family: Roboto;
            display: block;
            color: #000;
            padding-bottom: 10px;
        }

        [href$=".pdf"]::before {
            font-family: "FontAwesome";
            content: "\f1c1";
            margin-right: 2px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Add New Certificate</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('certificates.index')); ?>"> Back</a>
            </div>
        </div>
    </div>


    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <form action="<?php echo e(route('certificates.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="container-fluid pt-4 px-4">
            <div class="row g-4">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Type:</strong>

                        <select class="form-select" id="floatingSelect" aria-label="Floating label select example">
                            <option selected>Select Options</option>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($val->id); ?>" data-href= "<?php echo e($val->image); ?>"><?php echo e($val->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </select>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group downloadfiles">

                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>File:</strong>
                        <input type="file" class="form-control" id="image" name="image">
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>


    </form>


    <p class="text-center text-primary"><small></small></p>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('#floatingSelect').on('change', function() {
            alert(this.value);
            var data = $(this).find('option:selected').data('href');
            console.log($(this).find('option:selected').data('href'));
            var url = '<?php echo e(url('/uploads/form/')); ?>' + '/' + data;
            console.log(url);
            $('.downloadfiles').append('<strong>File:</strong><a href=' + url + '>Download Free Book</a>');

        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\nalavariyam\resources\views/certificate/create.blade.php ENDPATH**/ ?>